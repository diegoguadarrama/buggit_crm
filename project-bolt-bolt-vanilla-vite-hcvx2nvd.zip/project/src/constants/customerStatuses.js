export const CUSTOMER_STATUSES = [
  'lead',
  'qualified',
  'proposal',
  'negotiation',
  'closed',
  'lost',
];